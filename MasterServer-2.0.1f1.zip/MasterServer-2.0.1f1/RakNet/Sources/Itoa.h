#ifndef __RAK_ITOA_H
#define __RAK_ITOA_H

#include "Export.h"

RAK_DLL_EXPORT char* Itoa( int value, char* result, int base );

#endif
